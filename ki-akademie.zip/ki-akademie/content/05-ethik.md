:::module{id="5" title="KI-Ethik" duration="30"}

:::title-slide

# Ethik und KI

Verantwortungsvoller Einsatz als Geschäftsnotwendigkeit

---slide---

## Warum KI-Ethik Business-relevant ist

:::info
**46%** der Führungskräfte identifizieren verantwortungsvolle KI als zentrales Wettbewerbsziel.
:::

- Regulierung verschärft sich global
- Ethische Fehltritte = Reputationsschäden
- Kundevertrauen ist kritisch
- Rechtliche Konsequenzen drohen

---slide---

## Problem 1: Algorithmische Voreingenommenheit (Bias)

**KI kann Vorurteile aus Trainingsdaten übernehmen und verstärken!**

**Reales Beispiel – Amazon:**
KI-Rekrutierungssystem bevorzugte Männer für technische Positionen. Warum? Trainiert auf 10 Jahren männerdominierter Lebensläufe.

→ System wurde eingestellt.

---slide---

## Weitere Bias-Beispiele

**Gesundheitsalgorithmus USA:**
- Bevorzugte weisse Patienten
- Grund: Gesundheitsausgaben als Proxy für Bedarf
- Schwarze Patienten hatten historisch weniger Zugang

**Gesichtserkennung:**
- Fehlerrate hellhäutige Männer: **0.8%**
- Fehlerrate dunkelhäutige Frauen: **34.7%**

---slide---

## Problem 2: Black Box – Fehlende Erklärbarkeit

**Viele KI-Systeme können ihre Entscheidungen nicht erklären.**

**Folgen:**
- Nutzer verstehen Entscheidungen nicht
- Audits sind schwierig
- Compliance wird erschwert
- Informierte Einwilligung kaum möglich

**HireVue-Beispiel:** Video-Interview-KI bewertete Mimik & Tonfall – niemand konnte erklären, wie.

---slide---

## Problem 3: Wer haftet?

Wer ist verantwortlich, wenn KI schädliche Entscheidungen trifft?

- Der Entwickler?
- Der Betreiber?
- Die nutzende Organisation?

**Wichtig für Sie:**
Als Organisation, die Dritt-KI einsetzt, **bleiben Sie für die Ergebnisse verantwortlich!**

---slide---

## Problem 4: Deepfakes & Desinformation

**Gefälschte Videos und Audio für:**
- Finanzbetrug
- Politische Manipulation
- Identitätsdiebstahl

**Reale Fälle 2024:**
- KI-Robocall imitiert Präsident Biden → CHF 6 Mio. Strafe
- Deepfake-Audio beschuldigt Schulleiter → Morddrohungen

---slide---

## Problem 5: Umweltbelastung

:::warning
Training von GPT-3: **500 Tonnen CO₂** – entspricht 438 Flügen NY-San Francisco
:::

- Eine ChatGPT-Anfrage: bis zu **100x mehr Energie** als eine Google-Suche
- US-Rechenzentren: 4.4% des US-Stroms
- 80-90% der KI-Energie entfällt auf tägliche Nutzung, nicht Training

---slide---

## Internationale Leitlinien

**EU-Ethikleitlinien für vertrauenswürdige KI (2019):**
1. Menschliche Kontrolle & Aufsicht
2. Technische Robustheit & Sicherheit
3. Privatsphäre & Daten-Governance
4. Transparenz
5. Vielfalt & Nichtdiskriminierung
6. Gesellschaftliches Wohlergehen
7. Rechenschaftspflicht

---slide---

## OECD-KI-Prinzipien

**Von 47 Ländern angenommen (inkl. CH)**

1. Inklusives Wachstum
2. Menschenrechte schützen
3. Transparenz gewährleisten
4. Robustheit & Sicherheit
5. Rechenschaftspflicht

---slide---

## Fragen an Ihren KI-Anbieter

**Vor der Tool-Auswahl klären:**

- Auf welchen Daten wurde trainiert?
- Wurden Bias-Tests durchgeführt?
- Wie werden Unternehmensdaten gehandhabt?
- Werden meine Daten fürs Training verwendet?
- Gibt es ein KI-Ethik-Framework?
- Wie wird menschliche Aufsicht ermöglicht?

---slide---

:::exercise{type="multiple-choice" id="ex-ethik" title="Ethische Herausforderung" points="15"}
question: Ein KI-System zur Bewerberauswahl lehnt überproportional Kandidaten mit ausländisch klingenden Namen ab. Was ist die wahrscheinlichste Ursache?
options:
- Das System ist absichtlich diskriminierend programmiert
- Die Trainingsdaten enthielten historische Bias
- Die KI hat "gelernt", ausländische Namen zu erkennen
- Der Algorithmus ist zu alt
correct: B
hint: Denken Sie daran, woher KI "lernt".
:::

---slide---

:::exercise{type="text-input" id="ex-ethik-reflexion" title="Reflexion" points="10"}
question: Nennen Sie ein konkretes Beispiel aus Ihrem Arbeitsbereich, wo KI-Bias ein Risiko darstellen könnte.
placeholder: Beschreiben Sie eine Situation, in der Voreingenommenheit problematisch werden könnte...
minLength: 50
maxLength: 300
:::

:::endmodule
