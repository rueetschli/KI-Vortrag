:::module{id="7" title="Praxis: Vertrieb & CRM" duration="40"}

:::title-slide

# KI im Vertrieb

Lead-Scoring, Kundenanalyse und Verkaufsoptimierung

---slide---

## Der Vertrieb transformiert sich

:::info
**98%** der Vertriebsteams mit KI berichten verbesserte Lead-Priorisierung.
:::

**Die goldene Regel:** Reaktion innerhalb von 5 Minuten erhöht die Terminchance um das **100-fache**!

KI hilft, die richtigen Leads zur richtigen Zeit zu kontaktieren.

---slide---

## Tool: Salesforce Einstein

**Lead-Scoring mit Machine Learning:**
- Analysiert historische CRM-Daten
- Identifiziert Muster bei konvertierenden Leads
- Bewertet neue Leads automatisch
- Zeigt *warum* ein Lead gut bewertet ist

**Voraussetzungen:**
- Salesforce Enterprise Edition
- Min. 1'000 Leads, 120 Konversionen (6 Monate)

---slide---

## Tool: Gong – Gesprächsanalyse

**Was Gong kann:**
- Alle Kundeninteraktionen aufzeichnen
- Automatisch analysieren
- Coachbare Momente identifizieren
- Wettbewerber-Erwähnungen erkennen

**Resultate:**
- **15-20%** schnellere Deal-Abschlüsse
- **12-18%** höhere Gewinnraten
- **6'700 Stunden** gespart (ein Kunde)

**Preis:** CHF 5'000-50'000/Jahr

---slide---

## Tool: HubSpot Breeze Agents

**Drei spezialisierte KI-Agenten:**

1. **Prospecting Agent**
   - Recherchiert Accounts automatisch
   - Personalisiert Outreach

2. **Customer Agent**
   - Löst 50%+ Support-Tickets autonom
   
3. **Data Agent**
   - Beantwortet Fragen über Kunden

---slide---

## Praxis: KI-gestützter Verkaufsprozess

**Phase 1: Lead-Generierung**
- KI identifiziert ideale Kundenprofile
- Automatische Anreicherung mit Daten

**Phase 2: Qualifizierung**
- Lead-Scoring priorisiert automatisch
- KI schlägt beste Kontaktzeit vor

**Phase 3: Engagement**
- Personalisierte E-Mail-Vorlagen
- Gesprächsleitfäden basierend auf Analyse

**Phase 4: Abschluss**
- Einwand-Handling Vorschläge
- Prognose der Abschlusswahrscheinlichkeit

---slide---

## Prompt-Beispiel: Verkaufs-E-Mail

```
Schreibe eine Kaltakquise-E-Mail.

Empfänger: [Rolle] bei [Firma]
Branche: [Branche]
Unser Produkt: [Kurzbeschreibung]
Schmerzpunkt: [Problem das wir lösen]

Anforderungen:
- Max. 150 Wörter
- Personalisierter Einstieg
- Ein konkreter Mehrwert
- Klare, einfache CTA
- Keine Floskeln wie "Ich hoffe..."
```

---slide---

## CRM-Automatisierung

**Was KI im CRM automatisieren kann:**

- Kontaktdaten anreichern & aktualisieren
- E-Mails zusammenfassen
- Follow-up Erinnerungen
- Meeting-Notizen erstellen
- Nächste Schritte vorschlagen
- Pipeline-Prognosen

:::warning
**Wichtig:** KI ersetzt nicht die Beziehung – sie gibt Ihnen mehr Zeit dafür!
:::

---slide---

:::exercise{type="multiple-choice" id="ex-sales" title="Vertriebsoptimierung" points="15"}
question: Ihr Vertriebsteam hat Schwierigkeiten, die vielversprechendsten Leads zu identifizieren. Sie haben Salesforce im Einsatz. Was ist der sinnvollste erste Schritt?
options:
- Mehr Leads kaufen
- Salesforce Einstein Lead-Scoring aktivieren
- Alle Leads manuell anrufen
- Ein neues CRM einführen
correct: B
hint: Nutzen Sie bestehende Infrastruktur intelligent.
:::

---slide---

:::exercise{type="text-input" id="ex-sales-usecase" title="Ihr Vertrieb" points="10"}
question: Beschreiben Sie eine repetitive Aufgabe in Ihrem Vertriebsalltag, die KI übernehmen könnte.
placeholder: Z.B. "Ich verbringe 2 Stunden täglich mit..."
minLength: 30
maxLength: 250
:::

:::endmodule
