:::module{id="6" title="Praxis: Marketing & Content" duration="40"}

:::title-slide

# KI im Marketing

Content-Erstellung, Visuals und Kampagnen-Optimierung

---slide---

## Der Marketing-Gamechanger

:::info
Erwartete Vorteile durch KI im Marketing:
- **5x schnellere** Entwürfe
- **60% weniger** manuelle Überarbeitung
- Dokumentierte Fälle mit **342% ROI**
:::

**Aber:** 97% der KI-Inhalte benötigen menschliche Bearbeitung!

---slide---

## Tool: Jasper AI für Content

**Was kann Jasper?**
- Blogbeiträge
- Social-Media-Texte
- Werbeschlagzeilen
- E-Mail-Kampagnen
- Produktbeschreibungen

**Praxis:** Adidas nutzt Jasper für 150+ Schuhmodell-Beschreibungen

**Preis:** ab CHF 39/Monat (Creator)

---slide---

## Tool: Canva AI für Visuals

**Magic Studio Features:**
- **Magic Design** – Komplette Designs aus Prompts
- **Magic Resize** – Automatische Anpassung für alle Plattformen
- **Magic Edit** – KI-gestützte Bildbearbeitung

**Zeitersparnis:** 8+ Stunden pro Kampagne

**Preis:** Pro CHF 12.99/Monat

---slide---

## Workflow: Blog-Artikel mit KI

**Schritt 1:** Recherche mit Perplexity (Quellen!)

**Schritt 2:** Struktur erstellen mit Claude
- Zielgruppe definieren
- Kernbotschaft festlegen

**Schritt 3:** Entwurf mit ChatGPT/Jasper

**Schritt 4:** Mensch überarbeitet
- Fakten prüfen
- Ton anpassen
- SEO optimieren

---slide---

## Prompt-Beispiel: Social Media Post

```
Schreibe einen LinkedIn-Post für [Firma].

Thema: [Thema]
Ziel: [Engagement/Leads/Brand Awareness]
Ton: [Professionell/Locker/Inspirierend]
Länge: Max. 200 Wörter

Struktur:
- Hook (erste Zeile)
- Problem/Insight
- Lösung/Tipp
- Call-to-Action
- 3-5 relevante Hashtags
```

---slide---

## E-Mail-Marketing mit HubSpot AI

**Breeze AI Features:**
- Personalisierte Inhalte aus CRM-Daten
- Optimale Sendezeit vorhersagen
- Automatische A/B-Tests

:::success
Personalisierte E-Mails erreichen **29% höhere Öffnungsraten** und **58% höhere Konversionsraten**.
:::

---slide---

## SEO-Optimierung mit KI

**Tools:**
- **Surfer SEO** – Content-Score & Optimierung
- **Clearscope** – Keyword-Integration
- **MarketMuse** – Content-Strategie

**KI-gestützter Workflow:**
1. Keyword-Recherche (Ahrefs/SEMrush)
2. Konkurrenz analysieren
3. KI-Entwurf erstellen
4. Mit SEO-Tool optimieren
5. Mensch finalisiert

---slide---

:::exercise{type="demo" id="demo-marketing" title="Live: Marketing-Prompt" points="0"}
question: Marketing-Assistent
description: Testen Sie verschiedene Prompts für Marketing-Texte.
:::

---slide---

:::exercise{type="multiple-choice" id="ex-marketing" title="Marketing-Tool Auswahl" points="10"}
question: Sie müssen schnell Social-Media-Visuals für 5 verschiedene Plattformen erstellen. Welches Tool ist am effizientesten?
options:
- Midjourney
- Canva AI mit Magic Resize
- Adobe Photoshop
- DALL-E 3
correct: B
hint: Denken Sie an die Anforderung "5 verschiedene Plattformen".
:::

:::endmodule
