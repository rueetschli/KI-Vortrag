:::module{id="2" title="Die KI-Landschaft 2025" duration="60"}

:::title-slide

# Die KI-Landschaft 2025

Was für Künstliche Intelligenzen gibt es aktuell?

---slide---

## Sechs Hauptkategorien der KI

1. **Generative KI** – Text, Bild, Video, Audio erstellen
2. **Machine Learning** – Aus Daten lernen und vorhersagen
3. **Computer Vision** – Bilder und Videos verstehen
4. **Natural Language Processing** – Sprache verstehen
5. **Robotik & Automation** – Physische Aufgaben
6. **KI-Agenten** – Autonome Aufgabenausführung

---slide---

## Generative KI: Der Star des Jahres

**Was kann Generative KI?**

- **Texte** schreiben (Artikel, E-Mails, Code)
- **Bilder** erstellen (Marketing, Produktfotos)
- **Videos** generieren (Werbung, Erklärvideos)
- **Audio** produzieren (Stimmen, Musik)

:::info
Generative KI erstellt *neue* Inhalte basierend auf Mustern aus Trainingsdaten – sie kopiert nicht, sondern kreiert.
:::

---slide---

## Die grossen Sprachmodelle (LLMs)

| Anbieter | Modell | Stärken |
|----------|--------|---------|
| OpenAI | GPT-4o | Allrounder, Kreativität |
| Anthropic | Claude 3.5 | Lange Texte, Sicherheit |
| Google | Gemini 2.5 | Multimodal, Google-Integration |
| Microsoft | Copilot | Office-Integration |
| Meta | Llama 3 | Open Source |

---slide---

## ChatGPT im Detail

**Der Marktführer mit 800+ Millionen wöchentlichen Nutzern**

**Stärken:**
- Vielseitig einsetzbar
- Integrierte Bildgenerierung (DALL-E 3)
- Code-Analyse und -Generierung
- Deep Research für Tiefenrecherche

**Preise:**
- Free: Basis-Zugang
- Plus: CHF 20/Monat
- Team/Enterprise: ab CHF 25/Nutzer

---slide---

## Claude von Anthropic

**Der Sicherheits-Champion**

**Besonderheit:** 200'000 Token Kontextfenster
→ Kann ganze Bücher oder Codebasen analysieren!

**Stärken:**
- Herausragende Schreibqualität
- Fokus auf Sicherheit & Ethik
- Ideal für sensible Umgebungen

**Preis:** CHF 20/Monat (Pro)

---slide---

## Microsoft Copilot

**Der Office-Integrator**

Eingebettet in:
- **Word** – Dokumente entwerfen
- **Excel** – Formeln aus natürlicher Sprache
- **PowerPoint** – Präsentationen generieren
- **Outlook** – E-Mails zusammenfassen
- **Teams** – Meeting-Notizen

**Preis:** CHF 21-30/Nutzer/Monat

---slide---

## Google Gemini

**Der Multimodale**

- Verarbeitet Text, Bilder, Video, Audio gleichzeitig
- In Google Workspace integriert
- Über 40 Sprachen
- Stark bei strukturierten Daten

**Preis:** In Business-Plänen ab CHF 14/Nutzer

---slide---

:::exercise{type="multiple-choice" id="ex-llm" title="Welches Tool wofür?" points="10"}
question: Ein Schweizer KMU will KI in sein bestehendes Microsoft 365 integrieren. Welches Tool ist am sinnvollsten?
options:
- ChatGPT Plus
- Microsoft Copilot
- Google Gemini
- Claude Pro
correct: B
hint: Achten Sie auf die bestehende Infrastruktur des Unternehmens.
correct_feedback: Richtig! Copilot integriert sich nahtlos in bestehende Microsoft-Umgebungen.
incorrect_feedback: Microsoft Copilot bietet die beste Integration in Microsoft 365.
:::

---slide---

## Bildgeneratoren für Marketing

| Tool | Stärke | Preis |
|------|--------|-------|
| **Midjourney** | Künstlerische Qualität | ab $10/Mt |
| **DALL-E 3** | Prompt-Treue, Text in Bildern | in ChatGPT+ |
| **Stable Diffusion** | Open Source, anpassbar | Kostenlos* |
| **Adobe Firefly** | Commercial-Safe | in CC enthalten |

*Benötigt eigene Hardware oder Cloud

---slide---

## Trend 1: KI-Agenten

**Die nächste Stufe: KI, die selbstständig handelt**

Was Agenten können:
- Mehrstufige Aufgaben autonom ausführen
- Entscheidungen treffen
- Tools und APIs nutzen
- Aus Fehlern lernen

:::warning
Prognose: Bis 2029 werden **80% aller Kundenservice-Anfragen** autonom durch KI-Agenten gelöst.
:::

---slide---

## Trend 2: Multimodale KI

**Eine KI für alles**

Moderne Modelle verstehen und verarbeiten:
- 📝 Text
- 🖼️ Bilder
- 🎥 Videos
- 🔊 Audio
- 📊 Daten

**Alles in einer Abfrage kombinierbar!**

---slide---

## Trend 3: Small Language Models (SLMs)

**Gross ist nicht immer besser**

SLMs wie Phi-4, Llama 3.2, Gemma 3:
- Laufen **auf dem Gerät** (ohne Internet)
- **10-100x günstiger** als grosse Modelle
- Ideal für **Datenschutz**
- Perfekt für **spezifische Aufgaben**

---slide---

:::exercise{type="matching" id="ex-tools" title="Tool-Zuordnung" points="15"}
question: Ordnen Sie die Tools den passenden Anwendungsfällen zu:
pairs:
- Midjourney | Kreative Marketing-Visuals
- Microsoft Copilot | Excel-Formeln generieren
- Claude | Lange Verträge analysieren
- Perplexity | Recherche mit Quellenangaben
hint: Denken Sie an die Stärken jedes Tools.
:::

:::endmodule
