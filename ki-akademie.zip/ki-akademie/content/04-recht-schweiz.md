:::module{id="4" title="Recht & Datenschutz Schweiz" duration="45"}

:::title-slide

# Rechtslage in der Schweiz

nDSG, EU AI Act und was das für Ihr Unternehmen bedeutet

---slide---

## Schweizer Ansatz: Pragmatisch & Sektorspezifisch

:::info
**Februar 2025:** Der Bundesrat bestätigt – die Schweiz wird **kein umfassendes KI-Gesetz** einführen.
:::

Stattdessen:
- Bestehendes Datenschutzgesetz (nDSG)
- Sektorspezifische Regeln (FINMA etc.)
- Freiwillige Rahmenwerke
- Orientierung am EU AI Act

---slide---

## Das neue Datenschutzgesetz (nDSG)

**In Kraft seit 1. September 2023**

Der EDÖB bestätigt: Das Datenschutzgesetz ist *"direkt auf KI anwendbar"*

**Drei Kernbereiche für KI:**
1. Transparenzpflichten
2. Automatisierte Einzelentscheidungen
3. Datenschutz-Folgenabschätzungen

---slide---

## Transparenzpflichten (Art. 19-21)

**Was Sie offenlegen müssen:**

- Zweck des KI-Systems
- Funktionsweise (in verständlicher Form)
- Welche Daten verarbeitet werden

:::warning
**Betroffene Personen müssen erkennen können, wenn sie mit einer KI interagieren!**
:::

---slide---

## Automatisierte Einzelentscheidungen (Art. 21)

**Wann gilt dies?**

Wenn eine Entscheidung:
1. **Ausschliesslich** auf automatisierter Verarbeitung beruht
2. **UND** rechtliche Wirkungen hat
3. **ODER** die Person erheblich beeinträchtigt

**Rechte der Betroffenen:**
- Information über die Entscheidung
- Recht auf menschliche Überprüfung
- Standpunkt darlegen können

---slide---

## Profiling – Wann braucht es Einwilligung?

**Profiling =** Automatisierte Verarbeitung zur Bewertung von:
- Arbeitsleistung
- Wirtschaftliche Situation
- Gesundheit
- Interessen & Verhalten
- Standort

**Hochrisiko-Profiling** (erfordert ausdrückliche Einwilligung):
→ Wenn Datenverknüpfung eine Beurteilung *wesentlicher* Persönlichkeitsaspekte ermöglicht

---slide---

## Datenschutz-Folgenabschätzung (DSFA)

**Wann ist eine DSFA Pflicht?**

Bei Verarbeitungen mit *hohem Risiko* für Persönlichkeit oder Grundrechte, insbesondere durch:
- Neue Technologien (wie KI!)
- Art, Umfang und Zweck der Verarbeitung

**Die DSFA muss:**
1. Die Verarbeitung beschreiben
2. Risiken bewerten
3. Schutzmassnahmen dokumentieren

:::warning
Bei hohem Restrisiko: **EDÖB konsultieren** vor Verarbeitungsbeginn!
:::

---slide---

## Der EU AI Act – auch für die Schweiz relevant!

**In Kraft seit 1. August 2024**

**Wann gilt der EU AI Act für Schweizer Firmen?**

- KI-Systeme werden im EU-Markt angeboten
- KI-Outputs werden in der EU verwendet
- General-Purpose-KI-Modelle werden in der EU angeboten

---slide---

## EU AI Act: Risikoklassen

| Risiko | Beispiele | Anforderungen |
|--------|-----------|---------------|
| **Verboten** | Social Scoring, Manipulative KI | ❌ Nicht erlaubt |
| **Hoch** | Personal-Screening, Kredit-Scoring | Strenge Prüfung |
| **Limitiert** | Chatbots, Deepfakes | Transparenzpflicht |
| **Minimal** | Spam-Filter, Games | Keine Auflagen |

---slide---

## Timeline EU AI Act

- **Feb 2025:** Verbote & KI-Kompetenzpflicht in Kraft
- **Aug 2025:** Pflichten für General-Purpose-KI
- **Aug 2026:** Vollständige Anwendung Hochrisiko-KI

**Sanktionen:** Bis zu **35 Mio. Euro** oder **7% des globalen Umsatzes**

---slide---

## FINMA-Richtlinien für Finanzbranche

**Dezember 2024:** Neue KI-Governance-Anforderungen

- KI darf **keine Entscheidungsverantwortung** tragen
- Zentrales **KI-Inventar** erforderlich
- **Erklärbarkeit** der Outputs für Mitarbeitende
- **Menschliche Aufsicht** bei allen Entscheidungen

---slide---

:::exercise{type="multiple-choice" id="ex-recht" title="Rechtliche Pflichten" points="15"}
question: Ein Online-Shop nutzt KI zur automatischen Kreditwürdigkeitsprüfung. Welche Pflicht besteht gemäss nDSG SICHER?
options:
- Keine besonderen Pflichten
- Nur interne Dokumentation
- Information und Recht auf menschliche Überprüfung
- Bewilligung des EDÖB vor Einsatz
correct: C
hint: Art. 21 nDSG regelt automatisierte Einzelentscheidungen.
:::

---slide---

## Compliance-Checkliste für KMU

**Sofort umsetzen:**
- [ ] KI-Systeme mit Personendaten identifizieren
- [ ] Datenschutzerklärung um KI ergänzen
- [ ] Mechanismus für menschliche Überprüfung einrichten
- [ ] Verarbeitungsverzeichnis aktualisieren

**KI-Inventar anlegen:**
- [ ] Alle KI-Tools erfassen
- [ ] Zweck & Datenquellen dokumentieren
- [ ] Risikoklassifizierung vornehmen

---slide---

:::exercise{type="true-false" id="ex-schweiz" title="Schweizer KI-Recht" points="10"}
question: Die Schweiz plant ein eigenes, umfassendes KI-Gesetz nach dem Vorbild des EU AI Act.
correct: false
hint: Wie hat sich der Bundesrat im Februar 2025 positioniert?
correct_feedback: Richtig! Die Schweiz setzt auf einen sektorspezifischen Ansatz ohne eigenes KI-Gesetz.
incorrect_feedback: Falsch. Die Schweiz setzt auf bestehende Gesetze und sektorspezifische Regulierung.
:::

:::endmodule
