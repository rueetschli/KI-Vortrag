:::module{id="8" title="Praxis: Büro & Administration" duration="40"}

:::title-slide

# KI im Büroalltag

Meeting-Assistenten, Dokumentenmanagement und Übersetzung

---slide---

## Produktivität im Alltag steigern

:::success
Mitarbeitende sparen durchschnittlich **122 Stunden jährlich** bei einfachen Verwaltungsaufgaben durch KI.
:::

**Grösste Zeitfresser:**
- Meetings & Protokolle
- E-Mail-Bearbeitung
- Dokumentenerstellung
- Übersetzungen
- Dateneingabe

---slide---

## Tool: Otter.ai – Meeting-Assistent

**Features:**
- Echtzeit-Transkription (95% Genauigkeit)
- Automatische Zusammenfassungen
- Aufgaben-Extraktion
- Sprecheridentifikation

**ROI:**
- 10:1 für Enterprise-Kunden
- ~6 Mio. CHF Ersparnis bei 1'000 Nutzern

**Preis:** Free (300 Min), Pro CHF 17/Mt, Business CHF 30/Mt

---slide---

## Tool: Microsoft 365 Copilot

**Word:**
- Dokumente aus Prompts erstellen
- Texte umschreiben & kürzen

**Excel:**
- Formeln aus natürlicher Sprache
- Datenanalyse per Chat

**Outlook:**
- E-Mails zusammenfassen
- Antworten vorschlagen

**PowerPoint:**
- Präsentationen generieren
- Designs vorschlagen

---slide---

## Copilot in der Praxis

**Beispiel Word:**
> "Erstelle einen Projektvorschlag für die Einführung eines neuen CRM-Systems. Zielgruppe: Geschäftsleitung. Max. 2 Seiten."

**Beispiel Excel:**
> "Zeige mir den Umsatz nach Region als Balkendiagramm und markiere alle Werte unter 10'000 rot."

**Beispiel Outlook:**
> "Fasse diese E-Mail-Konversation zusammen und liste die offenen Punkte auf."

---slide---

## Tool: DeepL – Übersetzung

**Für die viersprachige Schweiz essentiell!**

- 37 Sprachen, 100+ Sprachpaare
- Dokumente mit Formatierung
- Glossare für Fachbegriffe
- DeepL Voice für Meetings

**ROI:** 345% über 3 Jahre (Forrester)

**Preis:** Free (1'500 Zeichen), Starter €9/Mt, Advanced €28/Mt

---slide---

## Workflow: Effizientes Meeting

**Vor dem Meeting:**
- KI erstellt Agenda aus E-Mail-Konversation
- Relevante Dokumente werden zusammengefasst

**Während des Meetings:**
- Otter/Teams transkribiert live
- Automatische Notizen

**Nach dem Meeting:**
- KI extrahiert Action Items
- Follow-up E-Mails werden vorgeschlagen
- Protokoll wird generiert

---slide---

## Google Workspace + Gemini

**Gmail:**
- E-Mails zusammenfassen
- Antworten vorschlagen

**Docs:**
- Texte generieren
- Zusammenfassungen erstellen

**Sheets:**
- Formeln vorschlagen
- Daten analysieren

**Meet:**
- KI-Notizen
- Automatische Untertitel

**Preis:** In Business-Plänen ab CHF 14/Nutzer

---slide---

## Schnelle Erfolge (Quick Wins)

| Tool | Zeitersparnis | Aufwand |
|------|--------------|---------|
| Otter.ai | 5-10 h/Woche | 5 Min Setup |
| DeepL | 2-4 h/Woche | Sofort |
| Canva AI | 8-20 h/Woche | 1 Tag |
| Copilot | 2-5 h/Woche | Bereits installiert |

:::info
**Empfehlung:** Starten Sie mit einem Tool, das sofort Wirkung zeigt!
:::

---slide---

:::exercise{type="multiple-choice" id="ex-buero" title="Tool-Auswahl Büro" points="10"}
question: Ihr Team führt viele Meetings auf Englisch mit internationalen Partnern. Welches Tool würde den grössten Mehrwert bieten?
options:
- Microsoft Word
- Otter.ai mit Transkription
- Excel mit Copilot
- PowerPoint Designer
correct: B
hint: Denken Sie an das Hauptproblem: Meetings in Fremdsprache.
:::

---slide---

:::exercise{type="scale" id="ex-zeitersparnis" title="Potenzial einschätzen" points="5"}
question: Wie viele Stunden pro Woche könnten Sie mit KI-Tools einsparen?
min: 0
max: 20
minLabel: 0 Stunden
maxLabel: 20+ Stunden
:::

:::endmodule
