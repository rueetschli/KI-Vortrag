:::module{id="10" title="Zusammenfassung & Abschluss" duration="15"}

:::title-slide

# Zusammenfassung

Was Sie heute gelernt haben und nächste Schritte

---slide---

## Die wichtigsten Erkenntnisse

**1. KI ist jetzt**
- 75% der Wissensarbeiter nutzen KI
- Wettbewerbsvorsprung durch frühe Adoption

**2. Rechtssicherheit beachten**
- nDSG gilt für KI
- Transparenz & menschliche Kontrolle

**3. Ethik ist Business-relevant**
- Bias vermeiden
- Verantwortung bleibt beim Menschen

**4. Praxis vor Theorie**
- Mit Quick Wins starten
- Iterativ verbessern

---slide---

## Ihre persönliche KI-Roadmap

**Diese Woche:**
- [ ] Ein Tool aus dem Kurs testen
- [ ] Ersten Use Case identifizieren

**Diesen Monat:**
- [ ] KI-Policy mit Team besprechen
- [ ] Pilotprojekt starten

**Dieses Quartal:**
- [ ] Erfolge messen
- [ ] Skalierung planen
- [ ] Weitere Anwendungsfälle

---slide---

## Empfohlene Starter-Tools

**Kostenlos starten:**
- ChatGPT Free
- Canva Free
- DeepL Free

**Für ernsthafte Nutzung:**
- ChatGPT Plus / Claude Pro (CHF 20/Mt)
- Canva Pro (CHF 13/Mt)
- Otter.ai Pro (CHF 17/Mt)

**Für Teams:**
- Microsoft Copilot
- HubSpot mit AI
- Salesforce Einstein

---slide---

## Ressourcen zum Weitlernen

**Dokumentation:**
- docs.anthropic.com (Claude)
- help.openai.com (ChatGPT)
- support.microsoft.com (Copilot)

**Communities:**
- Reddit: r/ChatGPT, r/artificial
- LinkedIn: KI & Marketing Gruppen

**Schweiz-spezifisch:**
- edoeb.admin.ch (Datenschutz)
- digitalswitzerland.com

---slide---

## Zertifikat

Nach Abschluss aller Module und Übungen erhalten Sie ein **Teilnahmezertifikat**.

**Voraussetzungen:**
- Alle Pflichtübungen abgeschlossen
- Mindestens 60% der Punkte erreicht

---slide---

:::exercise{type="scale" id="ex-zufriedenheit" title="Kurs-Feedback" points="5"}
question: Wie zufrieden sind Sie mit diesem Kurs?
min: 1
max: 10
minLabel: Nicht zufrieden
maxLabel: Sehr zufrieden
:::

---slide---

:::exercise{type="text-input" id="ex-feedback" title="Ihr Feedback" points="10"}
question: Was war das Wichtigste, das Sie heute gelernt haben? Was würden Sie verbessern?
placeholder: Teilen Sie uns Ihre Gedanken mit...
minLength: 20
maxLength: 500
:::

---slide---

## Vielen Dank!

Sie haben das Einführungsmodul abgeschlossen.

**Kontakt für Fragen:**
Wirtschaftsschule Five Digital

:::success
**Nächster Schritt:** Setzen Sie heute noch eines der gelernten Tools in die Praxis um!
:::

---slide---

:::title-slide

# 🎓

## Gratulation!

Sie haben alle Module erfolgreich abgeschlossen.

**Wirtschaftsschule Five | KI-Akademie**

:::endmodule
