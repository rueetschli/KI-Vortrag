:::module{id="9" title="Best Practices" duration="30"}

:::title-slide

# Best Practices

Prompting, häufige Fehler und ROI-Messung

---slide---

## Die Kunst des Promptings

**Regel Nr. 1: Klarheit siegt**

❌ Schlecht:
> "Erzähl mir über Vertrieb"

✅ Gut:
> "Erstelle eine 3-Absatz-Zusammenfassung der Q3-Verkäufe nach Region mit den Top-3-Performern. Zielgruppe: Geschäftsleitung."

---slide---

## Prompting-Framework: CRISP

**C** – Context (Kontext geben)
**R** – Role (Rolle zuweisen)
**I** – Instructions (Klare Anweisungen)
**S** – Specifics (Details wie Format, Länge)
**P** – Parameters (Einschränkungen)

---slide---

## Beispiel: CRISP angewendet

```
[Context]
Du bist Marketing-Experte für B2B-SaaS.

[Role]
Agiere als erfahrener Content-Stratege.

[Instructions]
Erstelle einen LinkedIn-Post über KI im HR.

[Specifics]
- Max. 150 Wörter
- Professioneller aber zugänglicher Ton
- Mit einer Frage zum Engagement enden

[Parameters]
- Keine Emojis
- Keine Buzzwords wie "revolutionär"
```

---slide---

## Chain-of-Thought Prompting

**Für komplexe Aufgaben:**

> "Bevor du deine Empfehlung gibst, gehe deine Überlegungen Schritt für Schritt durch. Berücksichtige Vor- und Nachteile jeder Option."

**Ideal für:**
- Komplexe Entscheidungen
- Finanzanalysen
- Compliance-Prüfungen

---slide---

## Häufiger Fehler 1: Übervertrauen

:::warning
**KI-Outputs können 2.5-22% Halluzinationen enthalten!**
:::

**Realer Fall:** Ein Anwalt reichte einen Schriftsatz mit 6 erfundenen Gerichtsfällen von ChatGPT ein → CHF 5'000 Strafe

**Lösung:** KI als "Praktikant" behandeln – immer prüfen!

---slide---

## Häufiger Fehler 2: Datenschutz ignorieren

**39%** der Verbraucher haben unwissentlich Arbeitsdaten in KI-Tools eingegeben.

**Niemals eingeben:**
- Vertrauliche Kundendaten
- Geschäftsgeheimnisse
- Personenbezogene Daten
- Passwörter oder Zugangsdaten

**Lösung:** Enterprise-Versionen mit Datenschutz nutzen

---slide---

## Häufiger Fehler 3: Kein Human-in-the-Loop

**KI soll unterstützen, nicht ersetzen!**

Immer menschliche Prüfung bei:
- Kundenkommmunikation
- Rechtlichen Dokumenten
- Finanzentscheidungen
- Personalentscheidungen

---slide---

## ROI messen: Das Framework

**Formel:**
> KI-ROI = (Generierter Wert - Gesamtinvestition) / Gesamtinvestition × 100

**Wert berechnen:**
- Gesparte Zeit × Stundenkosten
- Reduzierte Fehler
- Höhere Konversionsraten
- Schnellere Durchlaufzeiten

**Kosten erfassen:**
- Lizenzen
- Training
- Integration
- Wartung

---slide---

## Typische ROI-Werte

| Bereich | Ersparnis | Amortisation |
|---------|-----------|--------------|
| Content-Erstellung | 25-50% Zeit | 1-3 Monate |
| E-Mail-Marketing | 30-40% Zeit | 2-4 Monate |
| Lead-Scoring | 15-25% mehr Konversion | 2-3 Monate |
| Meeting-Protokolle | 80-90% Zeit | Sofort |

---slide---

## Implementierungs-Roadmap

**Woche 1-2:** Assessment
- Prozesse identifizieren
- Tool auswählen
- Pilot-Team definieren

**Woche 3-6:** Pilot
- Kleiner Test
- Feedback sammeln
- Anpassen

**Woche 7-12:** Rollout
- Training
- Skalierung
- Erfolgsmessung

---slide---

:::exercise{type="fill-blank" id="ex-prompt" title="Prompt verbessern" points="15"}
question: Verbessern Sie diesen Prompt durch Ergänzung der fehlenden Elemente.
text: Schreibe einen ___. Zielgruppe ist ___. Der Ton soll ___ sein. Maximale Länge: ___ Wörter.
blanks:
- Blogartikel über KI im Vertrieb
- B2B-Vertriebsleiter
- professionell aber zugänglich
- 500
:::

---slide---

:::exercise{type="multiple-choice" id="ex-fehler" title="Fehler vermeiden" points="10"}
question: Was ist der grösste Fehler beim Einsatz von KI für Kundenkommunikation?
options:
- KI-generierte Texte direkt verwenden ohne Prüfung
- Zu kurze Prompts schreiben
- Kostenlose Tools nutzen
- Mehrere Tools parallel testen
correct: A
hint: Denken Sie an "Halluzinationen" und Kundenbeziehungen.
:::

:::endmodule
