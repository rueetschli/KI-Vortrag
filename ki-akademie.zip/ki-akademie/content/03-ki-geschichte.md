:::module{id="3" title="Geschichte der KI" duration="30"}

:::title-slide

# Geschichte der KI

Von Turing bis ChatGPT: 80 Jahre in 30 Minuten

---slide---

## 1950: Alan Turing stellt die Frage

> "Können Maschinen denken?"

**Der Turing-Test:** Wenn ein Computer einen Menschen im Textgespräch davon überzeugen kann, ein Mensch zu sein, demonstriert er "Maschinenintelligenz".

:::info
**2025:** GPT-4.5 wurde in einer Studie in 73% der Fälle für einen Menschen gehalten.
:::

---slide---

## 1956: Die Geburt der KI

**Dartmouth-Konferenz** – Der Begriff "Artificial Intelligence" wird geprägt

Die Gründerväter:
- John McCarthy
- Marvin Minsky
- Claude Shannon

Ihre Vision: *"Jeder Aspekt des Lernens kann prinzipiell so präzise beschrieben werden, dass eine Maschine es simulieren kann."*

---slide---

## 1958: Das erste lernende Netzwerk

**Frank Rosenblatt** entwickelt das **Perceptron**

Das erste trainierbare neuronale Netzwerk!

> "Intelligenz wird nicht programmiert – sie wird gelernt."

Jedes moderne neuronale Netz ist ein direkter Nachfahre des Perceptrons.

---slide---

## 1974-1980: Der erste KI-Winter ❄️

**Was ging schief?**

Der Lighthill-Bericht (1973) urteilte: Die KI habe "völliges Versagen" bei ihren "grossspurigen Zielen" erreicht.

**Folgen:**
- Grossbritannien streicht alle KI-Förderung
- Forschungsgelder versiegen weltweit
- "KI-Winter" beginnt

---slide---

## 1980er: Expertensysteme – Boom und Bust

**Die Hoffnung:** Regelbasierte Systeme, die Expertenwissen kodifizieren

**Der Erfolg:** XCON sparte Digital Equipment 40 Mio. Dollar

**Der Fall:** 
- Teuer in der Wartung
- Schwer skalierbar
- 1987: Zweiter KI-Winter beginnt

---slide---

## 2012: Der Durchbruch

**30. September 2012** – AlexNet gewinnt ImageNet

Fehlerrate: nur **15.3%** (vorher: 26%)

**Was war anders?**
- Deep Learning (tiefe neuronale Netze)
- GPU-Computing (NVIDIA)
- Big Data (Internet)

Trainiert wurde das Netzwerk auf 2 Grafikkarten in einem Elternhaus!

---slide---

## 2016: AlphaGo schlägt den Weltmeister

**Go:** Komplexer als Schach – mehr Stellungen als Atome im Universum

**März 2016:** AlphaGo gewinnt 4:1 gegen Lee Sedol

**"Zug 37"** – Ein Zug mit 1:10'000 Wahrscheinlichkeit, der Jahrhunderte von Go-Strategie auf den Kopf stellte.

Für China ein "Sputnik-Moment" → Milliarden an KI-Investitionen

---slide---

## 2017: Die Transformer-Revolution

**"Attention Is All You Need"** – Das wichtigste KI-Paper der Dekade

Die Transformer-Architektur ermöglicht:
- Parallele Verarbeitung aller Wörter
- Besseres Kontextverständnis
- Schnelleres Training

**Das "T" in GPT steht für "Transformer"!**

---slide---

## 2022: ChatGPT verändert alles

**30. November 2022:** ChatGPT wird veröffentlicht

- 1 Million Nutzer in **5 Tagen**
- 100 Millionen in **2 Monaten**
- Das schnellste Wachstum einer App in der Geschichte

**2025:** 800 Millionen wöchentliche Nutzer

---slide---

:::exercise{type="ordering" id="ex-timeline" title="KI-Timeline" points="15"}
question: Bringen Sie diese KI-Meilensteine in die richtige chronologische Reihenfolge:
items:
- Turing-Test vorgeschlagen
- Dartmouth-Konferenz
- AlexNet gewinnt ImageNet
- AlphaGo schlägt Lee Sedol
- ChatGPT wird veröffentlicht
:::

---slide---

:::exercise{type="true-false" id="ex-history" title="Wahr oder Falsch?" points="10"}
question: Der Begriff "Künstliche Intelligenz" wurde erst in den 1980er Jahren geprägt.
correct: false
hint: Denken Sie an die Dartmouth-Konferenz.
correct_feedback: Richtig! Der Begriff wurde 1956 auf der Dartmouth-Konferenz geprägt.
incorrect_feedback: Der Begriff wurde bereits 1956 auf der Dartmouth-Konferenz geprägt.
:::

:::endmodule
