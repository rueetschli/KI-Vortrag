:::module{id="1" title="Willkommen" duration="15"}

:::title-slide

# Willkommen zur KI-Akademie

**Einführungsmodul Künstliche Intelligenz**

Wirtschaftsschule Five Digital

---slide---

## Ihr Dozent & Lernziele

Herzlich willkommen zu diesem 6-stündigen Einführungsmodul in die Welt der Künstlichen Intelligenz!

### Was Sie heute lernen werden:

- **Überblick** über aktuelle KI-Technologien und Tools
- **Geschichte** der KI – von Turing bis ChatGPT
- **Rechtslage** in der Schweiz (nDSG, EU AI Act)
- **Ethik** und verantwortungsvoller KI-Einsatz
- **Praxisanwendungen** für Marketing, Vertrieb & Büro

---slide---

## Warum KI jetzt wichtig ist

:::warning
**ChatGPT erreichte 100 Millionen Nutzer in nur 2 Monaten** – schneller als jede Technologie zuvor in der Geschichte.
:::

Zum Vergleich:
- TikTok brauchte **9 Monate**
- Instagram brauchte **2,5 Jahre**
- Facebook brauchte **4 Jahre**

**75% aller Wissensarbeiter** nutzen heute bereits KI-Tools im Beruf.

---slide---

## Der wirtschaftliche Impact

:::info
McKinsey schätzt den jährlichen Mehrwert durch Generative KI auf **6,1 bis 7,9 Billionen Dollar**.
:::

**Durchschnittlicher ROI:** CHF 3.70 Rendite pro investiertem Franken

**60%** der Organisationen erreichen ROI innerhalb von 12 Monaten

---slide---

## Kurs-Übersicht: 6 Stunden

| Block | Thema | Dauer |
|-------|-------|-------|
| 1 | KI-Landschaft 2025 | 60 Min |
| 2 | Geschichte der KI | 30 Min |
| 3 | Recht & Datenschutz Schweiz | 45 Min |
| 4 | Ethik & Verantwortung | 30 Min |
| 5 | Praxis: Marketing, Vertrieb, Büro | 120 Min |
| 6 | Best Practices & Abschluss | 45 Min |

---slide---

:::exercise{type="scale" id="ex-vorwissen" title="Selbsteinschätzung" points="5"}
question: Wie schätzen Sie Ihr aktuelles KI-Wissen ein?
min: 1
max: 10
minLabel: Anfänger
maxLabel: Experte
description: Bewerten Sie ehrlich – dies hilft uns, den Kurs anzupassen.
:::

:::endmodule
